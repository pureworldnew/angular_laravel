jquery-multiselect
==================

A jQuery plugin which converts all multiselect fields into checkboxes
